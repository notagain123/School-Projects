package com.south.openmrs.doctorsms;

/**
 * Created by angel on 4/30/16.
 */
public class NameValuePair {

    String name;
    String value;

    NameValuePair(String n, String v){
        name = n;
        value = v;
    }




}
