package com.south.openmrs.doctorsms;

/**
 * Created by angel on 5/21/16.
 */
public class Encryption {


    public void generatePrivateKeyPair(){

    }



}
