# DocRMS
An android application designed to let medical professionals and patients communicate with each other using end to end encryption.
